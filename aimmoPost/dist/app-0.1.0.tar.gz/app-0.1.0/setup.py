# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['app', 'app.schemas', 'app.views']

package_data = \
{'': ['*'], 'app': ['static/*']}

install_requires = \
['Flask-Classful>=0.14.2,<0.15.0',
 'Flask-Classy>=0.6.10,<0.7.0',
 'Flask-Cors>=3.0.10,<4.0.0',
 'Flask>=2.1.2,<3.0.0',
 'PyJWT>=2.4.0,<3.0.0',
 'apispec-webframeworks>=0.5.2,<0.6.0',
 'asyncio>=3.4.3,<4.0.0',
 'bcrypt>=3.2.2,<4.0.0',
 'blinker>=1.4,<2.0',
 'factory-boy>=3.2.1,<4.0.0',
 'flask-apispec>=0.11.1,<0.12.0',
 'flask-classful-apispec>=0.1.8,<0.2.0',
 'flask-mongoengine>=1.0.0,<2.0.0',
 'flask-restx>=0.5.1,<0.6.0',
 'flask-swagger-ui>=4.11.1,<5.0.0',
 'flask-swagger>=0.2.14,<0.3.0',
 'funcy>=1.17,<2.0',
 'marshmallow-mongoengine>=0.30.2,<0.31.0',
 'marshmallow>=3.17.0,<4.0.0',
 'mongoengine>=0.24.1,<0.25.0',
 'mongomock>=4.0.0,<5.0.0',
 'pylint>=2.14.3,<3.0.0',
 'pytest>=7.1.2,<8.0.0',
 'python-dotenv>=0.20.0,<0.21.0']

setup_kwargs = {
    'name': 'app',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'fhzpdlqk',
    'author_email': 'rozencrants@naver.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
