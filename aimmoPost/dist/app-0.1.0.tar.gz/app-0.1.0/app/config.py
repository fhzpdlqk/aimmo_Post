

class Config:
    TOKEN_KEY = "abcd"
    MONGODB_URI = "mongodb+srv://admin:abcd1234@cluster0.r5dv9.mongodb.net/?retryWrites=true&w=majority"
    ALGORITHM = "HS256"

class TestConfig:
    TOKEN_KEY = "abcd"
    MONGODB_URI = "mongomock://localhost"
    ALGORITHM = "HS256"
